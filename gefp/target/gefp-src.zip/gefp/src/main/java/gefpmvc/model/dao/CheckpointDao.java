package gefpmvc.model.dao;

import gefpmvc.model.Checkpoint;




public interface CheckpointDao {
	public Checkpoint getCheckpointById(Long  checkpointId);
}
