package gefpmvc.util;

public class Constants {

	public static String AUTHENTICATEDUSER = "authenticatedUser";
	
	public static String SESSIONPLANID = "sessionPlanId";
	public static String SESSIONDEPTID = "sessionDeptId";
	public static final String SESSIONCHECKPOINTID = "sessionCheckpointId";

}
