package gefpmvc.model.dao;

import gefpmvc.model.Runway;

import java.util.List;

public interface RunwayDao {

	public Runway getRunwayById(Long id);
	
	public List<Runway> getRunways();

	public Runway saveRunway(Runway runway);
}
