package gefpmvc.model.dao;

import gefpmvc.model.Role;

public interface RoleDao {
	public Role getRole(String roleName);
}
