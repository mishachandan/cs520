
    alter table cell 
        drop constraint FK_7mfxrj5s5ioa5l4nh75xe7ktr;

    alter table cell 
        drop constraint FK_kd96ryid6y6rj6gxn3ympfpyl;

    alter table cell 
        drop constraint FK_2m6b6yt2rfbadocnqhuspea3s;

    alter table checkpoint 
        drop constraint FK_r7ivispl65393grilsbpbtsci;

    alter table department 
        drop constraint FK_c175ko5bvxtf7vfbn2gwgofmk;

    alter table plan 
        drop constraint FK_cv9rugv2v0yair8dtup91l158;

    alter table plan_history 
        drop constraint FK_g4bxsolh1nvgursahsol30bq8;

    alter table plan_history 
        drop constraint FK_l45nfu52heg6btya20k8wit3t;

    alter table plan_runway 
        drop constraint FK_rd2n5mrpu4dyp3jnk1n7j4ekg;

    alter table plan_runway 
        drop constraint FK_p2ny0xpn3mh2g7g41smbkv02x;

    alter table plan_stage 
        drop constraint FK_1l3b25d3mbhv851n8xp6ebexs;

    alter table plan_stage 
        drop constraint FK_jb2ewda1kdwq6shdorpu7rq9d;

    alter table roles_privileges 
        drop constraint FK_8v41cqmc9gf5p3cmf5sjd9qqk;

    alter table roles_privileges 
        drop constraint FK_71bl89vbdxv104ovwet7a8l0m;

    alter table student_checkpoint 
        drop constraint FK_ctl6b28luyo7ojpr2j8itjd7w;

    alter table student_checkpoint 
        drop constraint FK_39o8ja5qg9lpwkjovbvqryylw;

    alter table user_roles 
        drop constraint FK_gtvhfoxqgeb6ghsg59yjakenx;

    alter table user_roles 
        drop constraint FK_lbvvqmh536gyici9px18cunf6;

    alter table users 
        drop constraint FK_gtnfk30beleksg1p96yp0x40x;

    alter table users 
        drop constraint FK_bu1n5kvk309ncjkb5rxi36smq;

    alter table users_test 
        drop constraint FK_hn95a8jef61y9iwf7rh45ae6n;

    drop table if exists authorities_test cascade;

    drop table if exists cell cascade;

    drop table if exists checkpoint cascade;

    drop table if exists department cascade;

    drop table if exists persistent_logins cascade;

    drop table if exists plan cascade;

    drop table if exists plan_history cascade;

    drop table if exists plan_runway cascade;

    drop table if exists plan_stage cascade;

    drop table if exists privilege cascade;

    drop table if exists role cascade;

    drop table if exists roles_privileges cascade;

    drop table if exists runway cascade;

    drop table if exists stage cascade;

    drop table if exists student_checkpoint cascade;

    drop table if exists user_roles cascade;

    drop table if exists users cascade;

    drop table if exists users_test cascade;

    drop sequence hibernate_sequence;
