package gefpmvc.model;


public enum RoleEnum {
	STUDENT,ADMIN,ADVISOR
}